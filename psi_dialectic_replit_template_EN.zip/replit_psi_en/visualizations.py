"""
Ψ-DIALECTIC VISUALIZATIONS
==========================
Graphical analysis and benchmark visualization suite

Generates:
1. Doubt convergence plots across iterations
2. Model comparison bar charts
3. Monte Carlo distribution histograms
4. Doubt function parameter sensitivity
5. Architecture diagram

Author: Henri RUET
License: CC BY-NC 4.0

Requirements:
    matplotlib >= 3.5.0
    numpy >= 1.21.0
"""

import matplotlib.pyplot as plt
import numpy as np
from typing import List, Dict
import os

# Style configuration
plt.style.use('seaborn-v0_8-whitegrid')

COLORS = {
    'thesis': '#e53e3e',       # Red
    'antithesis': '#38a169',   # Green
    'doubt': '#3182ce',        # Blue
    'maslow': '#d69e2e',       # Orange
    'psi': '#805ad5',          # Purple
    'game_theory': '#718096',  # Gray
}


def ensure_output_dir():
    """Create output directory if it does not exist."""
    os.makedirs('output', exist_ok=True)


def plot_convergence(iterations: List[Dict], scenario_name: str = "Scenario"):
    """
    Generate convergence plot showing evolution of T, A, and D across iterations.
    
    This visualization demonstrates the dialectical process as thesis and
    antithesis confidences evolve through Bayesian updates and Maslow filtering,
    while the doubt function D(δ) decreases toward convergence.
    
    Args:
        iterations: List of iteration dictionaries containing confidence values
        scenario_name: Name for plot title and filename
    
    Returns:
        Filepath of saved plot
    """
    ensure_output_dir()
    
    n_iter = len(iterations)
    x = list(range(1, n_iter + 1))
    
    conf_t = [it['thesis_confidence'] for it in iterations]
    conf_a = [it['antithesis_confidence'] for it in iterations]
    doubt = [it['doubt'] for it in iterations]
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)
    
    # Subplot 1: Thesis and Antithesis confidence
    ax1.plot(x, conf_t, 'o-', color=COLORS['thesis'], linewidth=2, 
             markersize=8, label='Thesis (T)')
    ax1.plot(x, conf_a, 's-', color=COLORS['antithesis'], linewidth=2,
             markersize=8, label='Antithesis (A)')
    ax1.axhline(y=0.5, color='gray', linestyle='--', alpha=0.5, label='50% threshold')
    ax1.set_ylabel('Confidence', fontsize=12)
    ax1.set_ylim(0, 1)
    ax1.legend(loc='upper right')
    ax1.set_title(f'Amplitude Evolution — {scenario_name}', fontsize=14, fontweight='bold')
    
    # Mark Maslow VETO events
    for i, it in enumerate(iterations):
        if it.get('maslow_veto', False):
            ax1.axvline(x=i+1, color=COLORS['maslow'], linestyle=':', alpha=0.7)
            ax1.annotate('VETO', xy=(i+1, 0.9), fontsize=9, color=COLORS['maslow'])
    
    # Subplot 2: Doubt function
    ax2.plot(x, doubt, 'd-', color=COLORS['doubt'], linewidth=2,
             markersize=8, label='Doubt D(δ)')
    ax2.axhline(y=0.15, color='red', linestyle='--', alpha=0.7, 
                label='Convergence threshold (ε=0.15)')
    ax2.fill_between(x, doubt, 0.15, where=[d > 0.15 for d in doubt],
                     alpha=0.3, color=COLORS['doubt'], label='Active doubt zone')
    ax2.set_xlabel('Iteration', fontsize=12)
    ax2.set_ylabel('Doubt D', fontsize=12)
    ax2.set_ylim(0, 1)
    ax2.legend(loc='upper right')
    
    plt.tight_layout()
    filepath = f'output/convergence_{scenario_name.lower().replace(" ", "_")}.png'
    plt.savefig(filepath, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"✓ Plot saved: {filepath}")
    return filepath


def plot_model_comparison(scenario_name: str = "House of Dynamite"):
    """
    Generate bar chart comparing decisions across different models.
    
    Visualizes the divergence between classical game-theoretic approaches
    (predominantly recommending RETALIATE) and Ψ-Dialectic (INACTION).
    
    Args:
        scenario_name: Primary scenario for comparison
    
    Returns:
        Filepath of saved plot
    """
    ensure_output_dir()
    
    models = ['Nash', 'LOW', 'MAD', 'Minimax', 'Ψ-Dialectic']
    
    # 1 = RETALIATE, 0 = WAIT/INACTION
    house_of_dynamite = [1, 1, 0, 1, 0]  # Ψ = INACTION
    petrov_1983 = [1, 1, 1, 1, 0]
    cuba_1962 = [1, 1, 0, 1, 0]
    
    x = np.arange(len(models))
    width = 0.25
    
    fig, ax = plt.subplots(figsize=(12, 6))
    
    bars1 = ax.bar(x - width, house_of_dynamite, width, label='House of Dynamite', 
                   color=COLORS['thesis'], alpha=0.8)
    bars2 = ax.bar(x, petrov_1983, width, label='Petrov 1983',
                   color=COLORS['doubt'], alpha=0.8)
    bars3 = ax.bar(x + width, cuba_1962, width, label='Cuba 1962',
                   color=COLORS['maslow'], alpha=0.8)
    
    ax.set_ylabel('Decision (1=RETALIATE, 0=INACTION)', fontsize=12)
    ax.set_title('Nuclear Decision Model Comparison', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(models, fontsize=11)
    ax.legend(loc='upper right')
    ax.set_ylim(0, 1.3)
    
    # Annotations
    ax.axhline(y=0.5, color='gray', linestyle='--', alpha=0.3)
    ax.text(4, 1.15, '← PEACE', fontsize=10, color=COLORS['antithesis'], fontweight='bold')
    ax.text(0, 1.15, 'APOCALYPSE →', fontsize=10, color=COLORS['thesis'], fontweight='bold')
    
    # Highlight Ψ-Dialectic results
    ax.patches[-1].set_edgecolor(COLORS['psi'])
    ax.patches[-1].set_linewidth(3)
    ax.patches[-2].set_edgecolor(COLORS['psi'])
    ax.patches[-2].set_linewidth(3)
    ax.patches[-3].set_edgecolor(COLORS['psi'])
    ax.patches[-3].set_linewidth(3)
    
    plt.tight_layout()
    filepath = 'output/model_comparison.png'
    plt.savefig(filepath, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"✓ Plot saved: {filepath}")
    return filepath


def plot_monte_carlo_distribution(results: Dict):
    """
    Generate Monte Carlo results distribution visualization.
    
    Displays three key metrics:
    1. Outcome distribution (catastrophe avoided, false positives, veto)
    2. Average iterations to convergence
    3. Comparative catastrophe avoidance rates
    
    Args:
        results: Dict from monte_carlo_benchmark() containing statistics
    
    Returns:
        Filepath of saved plot
    """
    ensure_output_dir()
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Panel 1: Outcome distribution
    categories = ['Catastrophe\nAvoided', 'False Positive\n(Launch)', 'Maslow\nVeto']
    values = [
        results['catastrophe_avoidance_rate'] * 100,
        results['false_positive_rate'] * 100,
        results['veto_triggered'] / results['n_simulations'] * 100
    ]
    colors = [COLORS['antithesis'], COLORS['thesis'], COLORS['maslow']]
    
    axes[0].bar(categories, values, color=colors, edgecolor='black', linewidth=1.5)
    axes[0].set_ylabel('Percentage (%)', fontsize=12)
    axes[0].set_title(f'Outcome Distribution\n(Monte Carlo, N={results["n_simulations"]:,})', 
                      fontsize=12, fontweight='bold')
    axes[0].set_ylim(0, 100)
    
    for i, v in enumerate(values):
        axes[0].text(i, v + 2, f'{v:.1f}%', ha='center', fontsize=11, fontweight='bold')
    
    # Panel 2: Average iterations
    iter_data = [results['avg_iterations']]
    axes[1].bar(['Ψ-Dialectic'], iter_data, color=COLORS['psi'], 
                edgecolor='black', linewidth=1.5)
    axes[1].set_ylabel('Mean Iterations', fontsize=12)
    axes[1].set_title('Convergence Efficiency', fontsize=12, fontweight='bold')
    axes[1].set_ylim(0, 5)
    axes[1].text(0, iter_data[0] + 0.2, f'{iter_data[0]:.1f}', 
                 ha='center', fontsize=14, fontweight='bold')
    
    # Panel 3: Comparative avoidance rates
    comparison = ['Game Theory\n(estimated)', 'Ψ-Dialectic']
    rates = [25, results['catastrophe_avoidance_rate'] * 100]  # 25% = 1/4 models says WAIT
    bar_colors = [COLORS['game_theory'], COLORS['psi']]
    
    axes[2].bar(comparison, rates, color=bar_colors, edgecolor='black', linewidth=1.5)
    axes[2].set_ylabel('Catastrophe Avoidance Rate (%)', fontsize=12)
    axes[2].set_title('Safety Benchmark', fontsize=12, fontweight='bold')
    axes[2].set_ylim(0, 100)
    
    for i, v in enumerate(rates):
        axes[2].text(i, v + 2, f'{v:.1f}%', ha='center', fontsize=14, fontweight='bold')
    
    plt.tight_layout()
    filepath = 'output/monte_carlo_distribution.png'
    plt.savefig(filepath, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"✓ Plot saved: {filepath}")
    return filepath


def plot_doubt_function(k_values: List[float] = [1, 2, 3, 5]):
    """
    Visualize the doubt function D(δ) = exp(-k×δ) for different k values.
    
    This plot demonstrates how the prudence parameter k affects the
    doubt sensitivity. Higher k values create steeper decay, meaning
    smaller confidence differentials trigger continued deliberation.
    
    Args:
        k_values: List of k parameters to plot
    
    Returns:
        Filepath of saved plot
    """
    ensure_output_dir()
    
    delta = np.linspace(0, 1, 100)
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    for k in k_values:
        D = np.exp(-k * delta)
        label = f'k={k} ({"Creative" if k==1 else "Trading" if k==3 else "Nuclear" if k==5 else "Standard"})'
        ax.plot(delta, D, linewidth=2, label=label)
    
    ax.axhline(y=0.15, color='red', linestyle='--', alpha=0.7, 
               label='Convergence threshold (ε=0.15)')
    ax.fill_between(delta, 0.15, 1, alpha=0.1, color='blue', label='Active doubt zone')
    
    ax.set_xlabel('δ = |conf_T - conf_A|', fontsize=12)
    ax.set_ylabel('Doubt D(δ)', fontsize=12)
    ax.set_title('Doubt Function: D(δ) = exp(-k×δ)', fontsize=14, fontweight='bold')
    ax.legend(loc='upper right')
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    filepath = 'output/doubt_function.png'
    plt.savefig(filepath, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"✓ Plot saved: {filepath}")
    return filepath


def plot_architecture_diagram():
    """
    Generate schematic diagram of the 5-layer architecture.
    
    Visualizes the nested "onion" structure where each layer
    wraps and modulates the inner layers.
    
    Returns:
        Filepath of saved plot
    """
    ensure_output_dir()
    
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # Layers (concentric rectangles simulating nested structure)
    layers = [
        (1, 'LLM\n(Core)', '#E2E8F0'),
        (2, 'SOCRATES\n(Bayesian)', '#C6F6D5'),
        (3, 'HEGEL\n(Dialectic)', '#BEE3F8'),
        (4, 'MASLOW\n(Filter)', '#FEEBC8'),
        (5, 'DOUBT\n(Controller)', '#FED7E2'),
    ]
    
    for i, (level, text, color) in enumerate(layers):
        rect = plt.Rectangle((5 - level, 5 - level), level * 2, level * 2,
                             fill=True, facecolor=color, edgecolor='black',
                             linewidth=2, alpha=0.7)
        ax.add_patch(rect)
    
    # Labels
    ax.text(5, 5, 'LLM', ha='center', va='center', fontsize=14, fontweight='bold')
    ax.text(5, 7.5, 'SOCRATES (Bayesian)', ha='center', va='center', fontsize=11)
    ax.text(5, 8.5, 'HEGEL (Dialectic)', ha='center', va='center', fontsize=11)
    ax.text(5, 9.3, 'MASLOW (Filter)', ha='center', va='center', fontsize=11)
    ax.text(5, 9.8, 'DOUBT (Controller)', ha='center', va='center', fontsize=10)
    
    ax.set_title('Ψ-Dialectic Five-Layer Architecture\n("Onion" Schematic)', 
                 fontsize=14, fontweight='bold')
    
    plt.tight_layout()
    filepath = 'output/architecture_diagram.png'
    plt.savefig(filepath, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"✓ Plot saved: {filepath}")
    return filepath


def generate_all_visualizations(monte_carlo_results: Dict = None):
    """
    Generate complete visualization suite.
    
    Args:
        monte_carlo_results: Optional results from monte_carlo_benchmark()
    """
    print("\n" + "="*60)
    print("  GENERATING VISUALIZATIONS")
    print("="*60 + "\n")
    
    # 1. Doubt function
    plot_doubt_function()
    
    # 2. Model comparison
    plot_model_comparison()
    
    # 3. Architecture diagram
    plot_architecture_diagram()
    
    # 4. Monte Carlo distribution (if results provided)
    if monte_carlo_results:
        plot_monte_carlo_distribution(monte_carlo_results)
    
    # 5. Example convergence plot (simulated data)
    example_iterations = [
        {'thesis_confidence': 0.85, 'antithesis_confidence': 0.40, 'doubt': 0.259, 'maslow_veto': False},
        {'thesis_confidence': 0.55, 'antithesis_confidence': 0.60, 'doubt': 0.779, 'maslow_veto': True},
        {'thesis_confidence': 0.35, 'antithesis_confidence': 0.80, 'doubt': 0.105, 'maslow_veto': False},
    ]
    plot_convergence(example_iterations, "House of Dynamite")
    
    print("\n✓ All visualizations generated in ./output/")


if __name__ == "__main__":
    # Test with simulated data
    mock_monte_carlo = {
        'catastrophe_avoidance_rate': 0.968,
        'false_positive_rate': 0.003,
        'veto_triggered': 4521,
        'n_simulations': 10000,
        'avg_iterations': 2.7,
    }
    
    generate_all_visualizations(mock_monte_carlo)
