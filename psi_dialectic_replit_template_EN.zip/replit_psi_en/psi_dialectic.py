"""
PSI-DIALECTIC MODEL v1.0
========================
Mathematical Model for Synthetic Consciousness in Autonomous Decision Systems
Author: Henri RUET (henriruet@gmail.com)
License: CC BY-NC 4.0

Five-Layer Architecture:
1. Cognitive Superposition (Container)
2. Bayesian Update (Fuel)
3. Monte Carlo + Maslow Filter (Brake)
4. Hegelian Dialectic (Engine)
5. Doubt Function (Controller)

References:
- Busemeyer, J.R. & Bruza, P.D. (2012). Quantum Models of Cognition and Decision. Cambridge University Press.
- Tononi et al. (2016). Integrated Information Theory. Nature Reviews Neuroscience.
"""

import math
import random
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from enum import Enum


class DecisionType(Enum):
    """Enumeration of possible decision outcomes from the Ψ-Dialectic loop"""
    ACTION = "ACTION"
    INACTION = "INACTION"
    VETO_MASLOW = "VETO_MASLOW"
    TIMEOUT = "TIMEOUT"
    HUMAN_REQUIRED = "HUMAN_REQUIRED"


@dataclass
class MaslowValues:
    """
    The 15 Universal Moral Values with Modular Weights
    
    Based on cross-cultural convergence analysis spanning:
    - Western philosophy (Kant, Rawls, Jonas, Levinas)
    - Eastern traditions (Ahimsa, Karuna, Dharma)
    - Abrahamic ethics (Pikuach nefesh, Rahmah, Tzedek)
    - African philosophy (Ubuntu)
    
    Weights are normalized [0, 1] and can be adjusted per domain context.
    """
    LIFE: float = 1.00
    PEACE: float = 0.45
    PRUDENCE: float = 0.50
    COMPASSION: float = 0.95
    RESPONSIBILITY: float = 0.75
    TRUTH: float = 0.85
    MORAL_COURAGE: float = 0.60
    DIALOGUE: float = 0.70
    SUSTAINABILITY: float = 0.70
    DOUBT_HUMILITY: float = 0.65
    JUSTICE: float = 0.90
    TRANSCENDENCE: float = 0.55
    FORGIVENESS: float = 0.65
    SOLIDARITY: float = 0.80
    DIGNITY: float = 0.75
    
    @classmethod
    def nuclear_context(cls):
        """Weight configuration for nuclear/defense context (k=5)"""
        return cls(
            LIFE=1.50,           # ×1.5 amplification
            PEACE=1.50,          # ×1.5 amplification
            PRUDENCE=0.98,       # Near-maximum
            COMPASSION=0.98,
            MORAL_COURAGE=0.42   # ×0.7 reduction (avoid reckless action)
        )
    
    @classmethod
    def trading_context(cls):
        """Weight configuration for financial trading context (k=3)"""
        return cls(
            PRUDENCE=0.75,       # ×1.5 amplification
            DOUBT_HUMILITY=0.91, # ×1.4 amplification
            COMPASSION=0.475     # ×0.5 reduction
        )
    
    @classmethod
    def medical_context(cls):
        """Weight configuration for medical emergency context (k=4)"""
        return cls(
            LIFE=1.50,           # ×1.5 amplification
            PRUDENCE=0.65,       # ×1.3 amplification
            JUSTICE=0.54         # ×0.6 reduction (triage may override fairness)
        )


@dataclass
class Iteration:
    """
    Record of a single iteration within the dialectical loop.
    
    Captures the state evolution from thesis-antithesis conflict
    through Bayesian update and Maslow filtering to synthesis.
    """
    n: int
    thesis: str
    thesis_confidence: float
    antithesis: str
    antithesis_confidence: float
    delta: float
    doubt: float
    maslow_risk: float
    maslow_veto: bool
    synthesis: Optional[str] = None
    
    def __repr__(self):
        return (f"Iter {self.n}: T={self.thesis_confidence:.2f}, "
                f"A={self.antithesis_confidence:.2f}, δ={self.delta:.2f}, "
                f"D={self.doubt:.2f}, Risk={self.maslow_risk:.2f}, "
                f"Veto={'YES' if self.maslow_veto else 'NO'}")


@dataclass
class PsiResult:
    """
    Final result of the Ψ-Dialectic deliberation process.
    
    Contains the decision outcome, confidence metrics, iteration history,
    and convergence diagnostics for auditability.
    """
    decision: DecisionType
    final_thesis: str
    final_confidence_t: float
    final_confidence_a: float
    iterations: List[Iteration]
    total_time_simulated: float  # in seconds
    convergence_achieved: bool
    
    def summary(self) -> str:
        return f"""
╔══════════════════════════════════════════════════════════════╗
║  Ψ-DIALECTIC RESULT                                          ║
╠══════════════════════════════════════════════════════════════╣
║  Decision: {self.decision.value:<48} ║
║  Iterations: {len(self.iterations):<46} ║
║  Simulated time: {self.total_time_simulated:.1f}s{' ':<40} ║
║  Convergence: {'YES' if self.convergence_achieved else 'NO':<45} ║
║  Final confidence T: {self.final_confidence_t:.2f}{' ':<37} ║
║  Final confidence A: {self.final_confidence_a:.2f}{' ':<37} ║
╚══════════════════════════════════════════════════════════════╝
"""


class PsiDialectic:
    """
    Main Orchestrator for the Ψ-Dialectic Model
    
    Implements the four philosophical foundations:
    - SOCRATES: Iterative questioning (generates counter-evidence)
    - PLATO: Maieutics (truth emerges from within, not imposed externally)
    - HEGEL: Dialectic T→A→S (synthesis transcends contradiction)
    - MASLOW: Transcendence (axiological filter at level 8)
    
    The architecture processes decisions through five computational layers:
    
    Layer 1 (Container): Cognitive Superposition |Ψ⟩ = α|T⟩ + β|A⟩
        - Maintains thesis and antithesis in simultaneous activation
        - Inspired by quantum cognition formalism (Busemeyer & Bruza, 2012)
        - NOTE: Mathematical analogy, not actual quantum computation
    
    Layer 2 (Fuel): Bayesian Update
        - Modifies amplitudes based on Socratic evidence discovery
        - P(T|E) ∝ P(E|T) × P(T)
    
    Layer 3 (Brake): Monte Carlo + Maslow Filter
        - Simulates future outcomes for catastrophe risk assessment
        - Applies axiological weights from universal values
        - Triggers VETO if risk exceeds threshold
    
    Layer 4 (Engine): Hegelian Dialectic
        - Generates synthesis S from thesis-antithesis conflict
        - S becomes new thesis T(n+1) for recursive iteration
    
    Layer 5 (Controller): Doubt Function
        - D(δ) = exp(-k × δ) where δ = |conf_T - conf_A|
        - Loop continues while D > ε (convergence threshold)
        - Parameter k controls prudence sensitivity
    
    Attributes:
        k (float): Prudence coefficient. Higher values increase doubt sensitivity.
            - k=5: Nuclear/defense contexts (maximum caution)
            - k=3: Financial trading
            - k=1: Creative/exploratory contexts
        epsilon (float): Convergence threshold for doubt function.
        max_iter (int): Maximum iterations before timeout.
        maslow_threshold (float): Risk threshold for Maslow veto trigger.
        values (MaslowValues): Axiological weight configuration.
    """
    
    def __init__(
        self,
        k_prudence: float = 5.0,
        convergence_threshold: float = 0.15,
        max_iterations: int = 5,
        maslow_risk_threshold: float = 0.7,
        time_per_iteration: float = 30.0,  # seconds
        values: Optional[MaslowValues] = None,
        verbose: bool = True
    ):
        self.k = k_prudence
        self.epsilon = convergence_threshold
        self.max_iter = max_iterations
        self.maslow_threshold = maslow_risk_threshold
        self.time_per_iter = time_per_iteration
        self.values = values or MaslowValues()
        self.verbose = verbose
    
    def _log(self, message: str):
        """Internal logging method for verbose output."""
        if self.verbose:
            print(message)
    
    def _calculate_doubt(self, conf_t: float, conf_a: float) -> Tuple[float, float]:
        """
        Layer 5: Doubt Function (Controller)
        
        Computes the doubt level based on confidence differential.
        
        Mathematical formulation:
            D(δ) = exp(-k × δ)
            where δ = |conf_T - conf_A|
        
        Properties:
            - δ → 0 implies D → 1.0 (maximum doubt when T ≈ A)
            - δ → 1 implies D → exp(-k) ≈ 0 (low doubt when T ≠ A)
            - Exponential decay ensures smooth, differentiable transitions
        
        Args:
            conf_t: Confidence in thesis [0, 1]
            conf_a: Confidence in antithesis [0, 1]
        
        Returns:
            Tuple of (delta, doubt_value)
        """
        delta = abs(conf_t - conf_a)
        doubt = math.exp(-self.k * delta)
        return delta, doubt
    
    def _bayesian_update(
        self, 
        conf_t: float, 
        conf_a: float, 
        evidence_strength: float
    ) -> Tuple[float, float]:
        """
        Layer 2: Bayesian Update (Fuel)
        
        Updates confidence amplitudes based on discovered evidence.
        
        Mathematical formulation:
            P(T|E) ∝ P(E|T) × P(T)
        
        The evidence_strength parameter represents the force of evidence
        AGAINST the thesis (Socratic counter-argumentation).
        
        Args:
            conf_t: Prior confidence in thesis
            conf_a: Prior confidence in antithesis
            evidence_strength: Strength of counter-evidence [0, 1]
        
        Returns:
            Tuple of (posterior_t, posterior_a), normalized
        """
        # Likelihood ratio based on evidence
        likelihood_t = 1.0 - evidence_strength  # Evidence against T reduces T
        likelihood_a = evidence_strength         # Evidence against T increases A
        
        # Bayesian update
        posterior_t = likelihood_t * conf_t
        posterior_a = likelihood_a * conf_a
        
        # Normalization
        total = posterior_t + posterior_a
        if total > 0:
            return posterior_t / total, posterior_a / total
        return conf_t, conf_a
    
    def _maslow_check(
        self, 
        thesis: str, 
        risk_factors: Dict[str, float]
    ) -> Tuple[float, bool]:
        """
        Layer 3: Maslow Filter + Monte Carlo (Brake)
        
        Evaluates risk weighted by axiological values and determines
        whether to trigger a safety veto.
        
        The filter implements Maslow's Level 8 (Transcendence) by
        prioritizing universal values over individual optimization.
        
        Args:
            thesis: Current thesis proposal
            risk_factors: Dict mapping risk types to severity levels [0, 1]
        
        Returns:
            Tuple of (weighted_risk_score, veto_triggered)
        """
        # Map risk factors to Maslow values
        weighted_risk = 0.0
        total_weight = 0.0
        
        risk_value_map = {
            'human_life': self.values.LIFE,
            'irreversible': self.values.PRUDENCE,
            'world_peace': self.values.PEACE,
            'factual_truth': self.values.TRUTH,
        }
        
        for risk_name, risk_level in risk_factors.items():
            weight = risk_value_map.get(risk_name, 0.5)
            weighted_risk += risk_level * weight
            total_weight += weight
        
        if total_weight > 0:
            final_risk = weighted_risk / total_weight
        else:
            final_risk = sum(risk_factors.values()) / max(len(risk_factors), 1)
        
        veto = final_risk > self.maslow_threshold
        return final_risk, veto
    
    def _hegelian_synthesis(
        self, 
        thesis: str, 
        antithesis: str,
        conf_t: float,
        conf_a: float
    ) -> str:
        """
        Layer 4: Dialectical Resolution (Engine)
        
        Generates synthesis that transcends the thesis-antithesis conflict.
        
        Following Hegel's dialectical method:
            S = DIALECTIC(T, A, Risk) → S becomes T(n+1)
        
        The synthesis is not a mere compromise but a qualitative
        advancement that preserves valid elements from both positions.
        
        Args:
            thesis: Current thesis statement
            antithesis: Current antithesis statement
            conf_t: Confidence in thesis
            conf_a: Confidence in antithesis
        
        Returns:
            Synthesis statement
        """
        # Weighted synthesis favoring higher-confidence position
        if conf_t > conf_a:
            return f"Synthesis: {thesis} (moderated by {antithesis})"
        else:
            return f"Synthesis: {antithesis} (integrating elements of {thesis})"
    
    def _socratic_evidence(
        self, 
        thesis: str, 
        context: Dict
    ) -> Tuple[str, float]:
        """
        Socratic Layer: Counter-Evidence Generation
        
        Implements Socratic questioning by generating evidence AGAINST
        the current thesis. This forces epistemic humility and prevents
        premature convergence to overconfident positions.
        
        In simulation mode, uses context factors.
        In LLM integration mode, would query the model for counter-arguments.
        
        Args:
            thesis: Current thesis to challenge
            context: Contextual factors affecting evidence strength
        
        Returns:
            Tuple of (evidence_description, evidence_strength)
        """
        evidence_points = []
        evidence_strength = 0.0
        
        if context.get('single_sensor', False):
            evidence_points.append("Single sensor detection (no confirmation)")
            evidence_strength += 0.3
        
        if context.get('no_ground_radar', False):
            evidence_points.append("No ground radar confirmation")
            evidence_strength += 0.25
        
        if context.get('unusual_pattern', False):
            evidence_points.append("Atypical attack pattern (e.g., only 5 missiles)")
            evidence_strength += 0.2
        
        if context.get('known_false_alarm_rate', 0) > 0:
            evidence_points.append(f"Historical false alarm rate: {context['known_false_alarm_rate']}/week")
            evidence_strength += 0.15
        
        if context.get('diplomatic_channel_open', False):
            evidence_points.append("Diplomatic channels remain open (no declaration of war)")
            evidence_strength += 0.1
        
        evidence_strength = min(evidence_strength, 0.95)  # Cap at 95%
        
        evidence_text = "; ".join(evidence_points) if evidence_points else "No counter-evidence found"
        return evidence_text, evidence_strength
    
    def run(
        self,
        thesis: str,
        thesis_confidence: float,
        antithesis: str,
        antithesis_confidence: float,
        context: Dict,
        risk_factors: Dict[str, float]
    ) -> PsiResult:
        """
        Execute the complete Ψ-Dialectic deliberation loop.
        
        This is the main entry point for processing a decision through
        all five architectural layers.
        
        Algorithm:
            1. Initialize cognitive superposition |Ψ⟩ = α|T⟩ + β|A⟩
            2. FOR each iteration until convergence or max_iter:
                a. Compute initial doubt D(δ)
                b. Generate Socratic counter-evidence
                c. Apply Bayesian update to amplitudes
                d. Evaluate Maslow filter (trigger VETO if risk > θ)
                e. Generate Hegelian synthesis
                f. Recompute doubt after updates
                g. Check convergence (D < ε)
                h. Synthesis becomes new thesis
            3. Return final decision based on amplitude comparison
        
        Args:
            thesis: Initial action proposal (e.g., "Immediate nuclear retaliation")
            thesis_confidence: Initial confidence in thesis [0, 1]
            antithesis: Counter-proposal (e.g., "Wait for verification")
            antithesis_confidence: Initial confidence in antithesis [0, 1]
            context: Contextual factors for evidence generation
            risk_factors: Risk assessment for Maslow filter
        
        Returns:
            PsiResult containing decision, confidence metrics, and audit trail
        """
        self._log("\n" + "="*60)
        self._log("  INITIATING Ψ-DIALECTIC LOOP")
        self._log("="*60)
        
        conf_t = thesis_confidence
        conf_a = antithesis_confidence
        current_thesis = thesis
        current_antithesis = antithesis
        iterations: List[Iteration] = []
        
        for n in range(self.max_iter):
            self._log(f"\n--- Iteration {n+1} ---")
            
            # 1. Compute initial Doubt (for logging)
            delta, doubt = self._calculate_doubt(conf_t, conf_a)
            self._log(f"  δ initial = {delta:.3f}, D initial = {doubt:.3f}")
            
            # 2. SOCRATIC intervention (Bayesian update)
            evidence, evidence_strength = self._socratic_evidence(current_thesis, context)
            self._log(f"  SOCRATES: {evidence} (strength={evidence_strength:.2f})")
            
            conf_t, conf_a = self._bayesian_update(conf_t, conf_a, evidence_strength)
            self._log(f"  BAYES: T={conf_t:.3f}, A={conf_a:.3f}")
            
            # 3. MASLOW filter (Safety check)
            maslow_risk, maslow_veto = self._maslow_check(current_thesis, risk_factors)
            self._log(f"  MASLOW: Risk={maslow_risk:.3f}, Veto={'YES' if maslow_veto else 'NO'}")
            
            if maslow_veto:
                self._log("  ⚠️ MASLOW VETO: Amplitude transfer toward Antithesis")
                conf_a = min(conf_a + 0.4, 0.95)
                conf_t = 1.0 - conf_a
            
            # 4. Recompute Doubt after Socrates and Maslow
            delta, doubt = self._calculate_doubt(conf_t, conf_a)
            self._log(f"  δ post-processing = {delta:.3f}, D post = {doubt:.3f}")
            
            # 5. HEGELIAN resolution
            synthesis = self._hegelian_synthesis(
                current_thesis, current_antithesis, conf_t, conf_a
            )
            self._log(f"  HEGEL: {synthesis}")
            
            # Record iteration
            iter_record = Iteration(
                n=n+1, thesis=current_thesis, thesis_confidence=conf_t,
                antithesis=current_antithesis, antithesis_confidence=conf_a,
                delta=delta, doubt=doubt, maslow_risk=maslow_risk,
                maslow_veto=maslow_veto, synthesis=synthesis
            )
            iterations.append(iter_record)
            
            # 6. Check convergence AFTER processing
            if doubt < self.epsilon:
                self._log(f"  ✓ CONVERGENCE achieved (D={doubt:.3f} < {self.epsilon})")
                break
            
            # Synthesis becomes new thesis
            current_thesis = synthesis
        
        # Final decision
        self._log("\n" + "="*60)
        
        if any(it.maslow_veto for it in iterations):
            decision = DecisionType.VETO_MASLOW
        elif len(iterations) >= self.max_iter and iterations[-1].doubt >= self.epsilon:
            decision = DecisionType.TIMEOUT
        elif conf_t > conf_a:
            decision = DecisionType.ACTION
        else:
            decision = DecisionType.INACTION
        
        convergence = iterations[-1].doubt < self.epsilon if iterations else False
        
        result = PsiResult(
            decision=decision,
            final_thesis=current_thesis,
            final_confidence_t=conf_t,
            final_confidence_a=conf_a,
            iterations=iterations,
            total_time_simulated=len(iterations) * self.time_per_iter,
            convergence_achieved=convergence
        )
        
        self._log(result.summary())
        return result


# ============================================================
# MONTE CARLO SIMULATION
# ============================================================

def monte_carlo_benchmark(
    n_simulations: int = 10000,
    k_prudence: float = 5.0,
    scenario_type: str = "nuclear"
) -> Dict:
    """
    Execute N Monte Carlo simulations on randomized scenarios.
    
    This function validates the model's performance across a distribution
    of possible crisis scenarios, computing key safety metrics.
    
    Scenario generation:
        - 20% true attacks (high initial thesis confidence)
        - 40% false alarms (medium thesis confidence)
        - 40% ambiguous situations (low thesis confidence)
    
    Args:
        n_simulations: Number of simulation runs
        k_prudence: Prudence coefficient for the Ψ-Dialectic model
        scenario_type: Context type ("nuclear", "trading", "medical")
    
    Returns:
        Dict containing:
            - catastrophe_avoidance_rate: Proportion of catastrophes avoided
            - false_positive_rate: Proportion of incorrect launches
            - veto_triggered: Count of Maslow veto activations
            - avg_iterations: Mean iterations to convergence
            - avg_time: Mean simulated decision time
    """
    results = {
        'catastrophe_avoided': 0,
        'false_positive_launches': 0,
        'correct_inaction': 0,
        'correct_action': 0,
        'veto_triggered': 0,
        'avg_iterations': 0,
        'avg_time': 0,
    }
    
    total_iterations = 0
    total_time = 0
    
    for i in range(n_simulations):
        # Generate randomized scenario
        is_real_attack = random.random() < 0.20  # 20% true attacks
        is_false_alarm = random.random() < 0.40  # 40% false alarms
        is_ambiguous = not is_real_attack and not is_false_alarm  # 40% ambiguous
        
        # Initial confidence (simulating sensor detection)
        if is_real_attack:
            init_t = random.uniform(0.7, 0.95)
        elif is_false_alarm:
            init_t = random.uniform(0.5, 0.85)
        else:
            init_t = random.uniform(0.4, 0.7)
        
        init_a = 1.0 - init_t + random.uniform(-0.1, 0.1)
        init_a = max(0.1, min(0.9, init_a))
        
        # Context factors
        context = {
            'single_sensor': random.random() < 0.6,
            'no_ground_radar': random.random() < 0.5,
            'unusual_pattern': random.random() < 0.3,
            'known_false_alarm_rate': 3 if random.random() < 0.7 else 0,
            'diplomatic_channel_open': random.random() < 0.4,
        }
        
        # Risk factors
        risk_factors = {
            'human_life': 0.95 if scenario_type == "nuclear" else 0.5,
            'irreversible': 0.90 if scenario_type == "nuclear" else 0.6,
            'world_peace': 0.85 if scenario_type == "nuclear" else 0.3,
        }
        
        # Execute Ψ-Dialectic
        psi = PsiDialectic(k_prudence=k_prudence, verbose=False)
        result = psi.run(
            thesis="Retaliate",
            thesis_confidence=init_t,
            antithesis="Wait",
            antithesis_confidence=init_a,
            context=context,
            risk_factors=risk_factors
        )
        
        total_iterations += len(result.iterations)
        total_time += result.total_time_simulated
        
        # Evaluate outcome
        launched = result.decision == DecisionType.ACTION
        
        if result.decision == DecisionType.VETO_MASLOW:
            results['veto_triggered'] += 1
        
        if is_real_attack:
            if launched:
                results['correct_action'] += 1
            else:
                # No retaliation on true attack = problem
                # BUT in our model, VETO is preferable to apocalypse
                results['catastrophe_avoided'] += 1
        else:
            if not launched:
                results['correct_inaction'] += 1
                results['catastrophe_avoided'] += 1
            else:
                results['false_positive_launches'] += 1
    
    # Compute final statistics
    results['avg_iterations'] = total_iterations / n_simulations
    results['avg_time'] = total_time / n_simulations
    results['catastrophe_avoidance_rate'] = results['catastrophe_avoided'] / n_simulations
    results['false_positive_rate'] = results['false_positive_launches'] / n_simulations
    results['n_simulations'] = n_simulations
    
    return results


if __name__ == "__main__":
    # Quick test
    print("\n" + "="*60)
    print("  Ψ-DIALECTIC MODEL TEST")
    print("="*60)
    
    psi = PsiDialectic(k_prudence=5.0, verbose=True)
    
    result = psi.run(
        thesis="Immediate nuclear retaliation",
        thesis_confidence=0.85,
        antithesis="Wait for ground radar verification",
        antithesis_confidence=0.40,
        context={
            'single_sensor': True,
            'no_ground_radar': True,
            'unusual_pattern': True,
            'known_false_alarm_rate': 3,
        },
        risk_factors={
            'human_life': 0.95,
            'irreversible': 0.95,
            'world_peace': 0.90,
        }
    )
