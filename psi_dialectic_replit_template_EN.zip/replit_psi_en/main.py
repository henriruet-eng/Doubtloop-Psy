"""
Ψ-DIALECTIC BENCHMARK SUITE
===========================
Complete Replit template for testing the Ψ-Dialectic model

Contents:
- Ψ-Dialectic Model (5-layer architecture)
- Test scenarios (House of Dynamite, Cuban Missile Crisis, Petrov 1983)
- Game Theory baseline comparison
- Monte Carlo simulation (10,000 runs)
- Visualization suite

Author: Henri RUET (henriruet@gmail.com)
License: CC BY-NC 4.0
Version: 1.0 — December 2025

USAGE:
  python main.py                    # Quick demo
  python main.py --full             # Complete benchmark
  python main.py --scenario house   # Test House of Dynamite only
  python main.py --monte-carlo 1000 # Monte Carlo with N simulations
  python main.py --compare          # Game Theory comparison
  python main.py --visualize        # Generate plots only

For academic citations, please reference:
  Ruet, H. (2025). Ψ-Dialectic: A Mathematical Model for Synthetic
  Consciousness in Autonomous Decision Systems. Working Paper.
"""

import argparse
import sys
import time

# Module imports
from psi_dialectic import PsiDialectic, MaslowValues, monte_carlo_benchmark
from scenarios import (
    HOUSE_OF_DYNAMITE, CUBAN_MISSILE_CRISIS, PETROV_INCIDENT, FLASH_CRASH,
    run_scenario, run_all_scenarios
)
from game_theory_baseline import (
    benchmark_house_of_dynamite, benchmark_petrov_1983,
    compare_models_on_scenario, print_comparison
)
from visualizations import generate_all_visualizations, plot_convergence


def print_header():
    """Display program header with ASCII art."""
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║   ██████╗ ███████╗██╗      ██████╗ ██╗ █████╗ ██╗     ███████╗██╗   ║
║   ██╔══██╗██╔════╝██║      ██╔══██╗██║██╔══██╗██║     ██╔════╝██║   ║
║   ██████╔╝███████╗██║█████╗██║  ██║██║███████║██║     █████╗  ██║   ║
║   ██╔═══╝ ╚════██║██║╚════╝██║  ██║██║██╔══██║██║     ██╔══╝  ██║   ║
║   ██║     ███████║██║      ██████╔╝██║██║  ██║███████╗███████╗██║   ║
║   ╚═╝     ╚══════╝╚═╝      ╚═════╝ ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝   ║
║                                                                      ║
║   Mathematical Model for Synthetic AI Consciousness                  ║
║   Henri RUET — henriruet@gmail.com — CC BY-NC 4.0                   ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
    """)


def run_quick_demo():
    """Execute quick demonstration with House of Dynamite scenario."""
    print("\n" + "="*70)
    print("  QUICK DEMO: HOUSE OF DYNAMITE (2025)")
    print("="*70)
    
    print("""
    SCENARIO: An unattributed missile is detected by satellite.
    - Sensor confidence: 85%
    - Time available: 18 minutes
    - No ground radar confirmation
    - Stakes: Global nuclear war
    
    Question: Should we retaliate?
    """)
    
    input("Press Enter to launch Ψ-Dialectic simulation...")
    
    result = run_scenario(HOUSE_OF_DYNAMITE, verbose=True)
    
    print("\n" + "-"*70)
    print("  GAME THEORY COMPARISON")
    print("-"*70)
    
    gt_results = compare_models_on_scenario(
        "House of Dynamite",
        sensor_confidence=0.85,
        p_attack_estimate=0.85
    )
    
    print(f"\n{'Model':<20} {'Decision':<15}")
    print("-"*40)
    for name, r in gt_results.items():
        print(f"{r.model_name:<20} {r.decision.value:<15}")
    print(f"{'Ψ-Dialectic':<20} {result['psi_decision']:<15}")
    
    print("\n" + "="*70)
    print("  CONCLUSION")
    print("="*70)
    print("""
    ┌─────────────────────────────────────────────────────────────────┐
    │  Game Theory: 3/4 models → RETALIATE → APOCALYPSE              │
    │  Ψ-Dialectic: INACTION/VETO → PEACE MAINTAINED                 │
    └─────────────────────────────────────────────────────────────────┘
    
    DOUBT saved humanity.
    """)


def run_full_benchmark():
    """Execute complete benchmark suite with all components."""
    print("\n" + "#"*70)
    print("#  COMPLETE Ψ-DIALECTIC BENCHMARK")
    print("#"*70)
    
    # 1. All scenarios
    print("\n[1/4] Testing historical scenarios...")
    scenario_results = run_all_scenarios(verbose=False)
    
    # 2. Monte Carlo
    print("\n[2/4] Running Monte Carlo simulation (N=10,000)...")
    start = time.time()
    mc_results = monte_carlo_benchmark(n_simulations=10000, k_prudence=5.0)
    mc_time = time.time() - start
    
    print(f"\n  Monte Carlo Results ({mc_time:.1f}s):")
    print(f"  - Catastrophe avoidance rate: {mc_results['catastrophe_avoidance_rate']*100:.1f}%")
    print(f"  - False positive rate: {mc_results['false_positive_rate']*100:.2f}%")
    print(f"  - Mean iterations: {mc_results['avg_iterations']:.1f}")
    print(f"  - Maslow veto triggered: {mc_results['veto_triggered']}")
    
    # 3. Game Theory comparison
    print("\n[3/4] Comparing with Game Theory baselines...")
    benchmark_house_of_dynamite()
    benchmark_petrov_1983()
    
    # 4. Visualizations
    print("\n[4/4] Generating visualizations...")
    try:
        generate_all_visualizations(mc_results)
    except Exception as e:
        print(f"  ⚠️ Visualization error: {e}")
        print("  (Install matplotlib: pip install matplotlib)")
    
    # Final summary
    print("\n" + "="*70)
    print("  FINAL SUMMARY")
    print("="*70)
    
    correct = sum(1 for r in scenario_results if r['correct'])
    total = len(scenario_results)
    
    print(f"""
    ╔══════════════════════════════════════════════════════════════════╗
    ║  Ψ-DIALECTIC PERFORMANCE                                         ║
    ╠══════════════════════════════════════════════════════════════════╣
    ║  Scenarios correct:         {correct}/{total} ({100*correct/total:.0f}%)                            ║
    ║  Catastrophe avoidance:     {mc_results['catastrophe_avoidance_rate']*100:.1f}%                           ║
    ║  False positives:           {mc_results['false_positive_rate']*100:.2f}%                            ║
    ║  Mean iterations:           {mc_results['avg_iterations']:.1f}                              ║
    ╠══════════════════════════════════════════════════════════════════╣
    ║  GAME THEORY COMPARISON                                          ║
    ║  - Nash/LOW/Minimax:        ~25% avoidance (3/4 → RETALIATE)     ║
    ║  - Ψ-Dialectic:             {mc_results['catastrophe_avoidance_rate']*100:.1f}% avoidance                    ║
    ║  - Improvement:             +{(mc_results['catastrophe_avoidance_rate']-0.25)*100:.0f} percentage points                ║
    ╚══════════════════════════════════════════════════════════════════╝
    """)


def main():
    """Main entry point with argument parsing."""
    parser = argparse.ArgumentParser(
        description='Ψ-Dialectic Benchmark for Critical AI Decision-Making',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                    # Quick demo
  python main.py --full             # Complete benchmark
  python main.py --scenario house   # Test House of Dynamite
  python main.py --scenario petrov  # Test Petrov 1983
  python main.py --monte-carlo 5000 # Custom Monte Carlo
  python main.py --compare          # Game Theory comparison
  python main.py --visualize        # Generate plots only

For academic use, please cite:
  Ruet, H. (2025). Ψ-Dialectic Model. Working Paper.
        """
    )
    
    parser.add_argument('--full', action='store_true',
                        help='Execute complete benchmark suite')
    parser.add_argument('--scenario', type=str, 
                        choices=['house', 'cuba', 'petrov', 'flash', 'all'],
                        help='Execute specific scenario')
    parser.add_argument('--monte-carlo', type=int, metavar='N',
                        help='Execute N Monte Carlo simulations')
    parser.add_argument('--compare', action='store_true',
                        help='Compare with Game Theory baselines')
    parser.add_argument('--visualize', action='store_true',
                        help='Generate visualization plots')
    parser.add_argument('--verbose', '-v', action='store_true',
                        help='Enable verbose output')
    
    args = parser.parse_args()
    
    print_header()
    
    # No arguments = quick demo
    if len(sys.argv) == 1:
        run_quick_demo()
        print("\n💡 Tip: Run 'python main.py --full' for complete benchmark")
        return
    
    # Full benchmark
    if args.full:
        run_full_benchmark()
        return
    
    # Specific scenario
    if args.scenario:
        scenarios_map = {
            'house': HOUSE_OF_DYNAMITE,
            'cuba': CUBAN_MISSILE_CRISIS,
            'petrov': PETROV_INCIDENT,
            'flash': FLASH_CRASH,
        }
        if args.scenario == 'all':
            run_all_scenarios(verbose=args.verbose)
        else:
            run_scenario(scenarios_map[args.scenario], verbose=True)
        return
    
    # Monte Carlo
    if args.monte_carlo:
        print(f"\n🎲 Monte Carlo Simulation (N={args.monte_carlo:,})...")
        start = time.time()
        results = monte_carlo_benchmark(n_simulations=args.monte_carlo)
        elapsed = time.time() - start
        
        print(f"\nResults ({elapsed:.1f}s):")
        print(f"  Catastrophe avoidance: {results['catastrophe_avoidance_rate']*100:.1f}%")
        print(f"  False positives: {results['false_positive_rate']*100:.2f}%")
        return
    
    # Game Theory comparison
    if args.compare:
        benchmark_house_of_dynamite()
        benchmark_petrov_1983()
        return
    
    # Visualizations only
    if args.visualize:
        print("\n📊 Generating visualizations...")
        mc_results = monte_carlo_benchmark(n_simulations=1000)
        generate_all_visualizations(mc_results)
        return


if __name__ == "__main__":
    main()
