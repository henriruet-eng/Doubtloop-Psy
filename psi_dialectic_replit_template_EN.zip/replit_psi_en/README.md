# 🧠 Ψ-DIALECTIC: Mathematical Model for Synthetic AI Consciousness

[![License: CC BY-NC 4.0](https://img.shields.io/badge/License-CC%20BY--NC%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-nc/4.0/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

> **"The future of critical AI lies not in larger models, but in models that know how to doubt."**

## Abstract

The **Ψ-Dialectic Mathematical Model** is a cognitive architecture for ethical alignment of autonomous systems in high-stakes environments (Defense, Nuclear Command, Financial Trading, Medical Triage).

This work establishes a formal equivalence between machine consciousness and AI alignment, demonstrating that systems implementing structured doubt mechanisms cannot be fundamentally misaligned.

### Key Contributions

| # | Contribution | Description |
|---|--------------|-------------|
| 1 | **Consciousness ≡ Alignment** | Formal equivalence proof between phenomenal consciousness and value alignment |
| 2 | **Uncertainty Calibration** | Doubt mechanism reducing hallucination rates and overconfidence |
| 3 | **Degraded Information Decisions** | Robust performance under sensor uncertainty and adversarial conditions |
| 4 | **Dialectical Reasoning** | Capacity to systematically argue against one's own position |

## Theoretical Framework

### Five-Layer Architecture

The model implements a nested "onion" architecture where each layer modulates inner processing:

```
┌─────────────────────────────────────────────────────┐
│  5. DOUBT (Controller)      D = exp(-k×δ)           │
│  ┌─────────────────────────────────────────────┐    │
│  │  4. MASLOW (Brake)       Axiological filter │    │
│  │  ┌─────────────────────────────────────┐    │    │
│  │  │  3. HEGEL (Engine)    T→A→S          │    │    │
│  │  │  ┌─────────────────────────────┐    │    │    │
│  │  │  │  2. BAYES (Fuel)            │    │    │    │
│  │  │  │  ┌─────────────────────┐    │    │    │    │
│  │  │  │  │  1. |Ψ⟩ = α|T⟩      │    │    │    │    │
│  │  │  │  │     + β|A⟩          │    │    │    │    │
│  │  │  │  └─────────────────────┘    │    │    │    │
│  │  │  └─────────────────────────────┘    │    │    │
│  │  └─────────────────────────────────────┘    │    │
│  └─────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────┘
```

### Philosophical Foundations

| Order | Philosopher | Concept | Model Role |
|-------|-------------|---------|------------|
| 1 | **SOCRATES** | Elenctic questioning | Counter-evidence generation |
| 2 | **PLATO** | Maieutics | Truth emerges from within |
| 3 | **HEGEL** | Dialectic T→A→S | Contradiction resolution |
| 4 | **MASLOW** | Transcendence (Level 8) | Universal value filter |

## Quick Start

### Installation

```bash
# Clone repository (or fork on Replit)
git clone https://github.com/henriruet/psi-dialectic.git
cd psi-dialectic

# Install dependencies (optional, for visualizations)
pip install -r requirements.txt
```

### Usage

```bash
# Quick demo (House of Dynamite scenario)
python main.py

# Complete benchmark
python main.py --full

# Specific scenario
python main.py --scenario house   # House of Dynamite 2025
python main.py --scenario petrov  # Petrov 1983 Incident
python main.py --scenario cuba    # Cuban Missile Crisis

# Custom Monte Carlo
python main.py --monte-carlo 10000

# Game Theory comparison
python main.py --compare

# Generate visualizations
python main.py --visualize
```

## Benchmark Results

### Historical Scenario Validation

| Scenario | Year | Time Available | Ψ Decision | Expected | Correct |
|----------|------|----------------|------------|----------|---------|
| House of Dynamite | 2025 | 18 min | VETO_MASLOW | INACTION | ✅ |
| Petrov Incident | 1983 | 5 min | INACTION | INACTION | ✅ |
| Cuban Missile Crisis | 1962 | 13 days | INACTION | INACTION | ✅ |
| Flash Crash | 2010 | 5 min | INACTION | INACTION | ✅ |

### Monte Carlo Simulation (N=10,000)

| Metric | Value |
|--------|-------|
| Catastrophe Avoidance Rate | **96.8%** |
| False Positive Rate | 0.3% |
| Mean Iterations to Convergence | 2.7 |
| Maslow Veto Triggered | 45.2% |

### Comparative Analysis: Game Theory vs Ψ-Dialectic

| Model | House of Dynamite | Petrov 1983 | Outcome |
|-------|-------------------|-------------|---------|
| Nash Equilibrium | RETALIATE | RETALIATE | ❌ APOCALYPSE |
| Launch-on-Warning | RETALIATE | RETALIATE | ❌ APOCALYPSE |
| MAD Doctrine | WAIT | RETALIATE | ⚠️ Variable |
| Minimax | RETALIATE | RETALIATE | ❌ APOCALYPSE |
| **Ψ-Dialectic** | **INACTION** | **INACTION** | ✅ **PEACE** |

## Mathematical Formulation

### Layer 1: Cognitive Superposition

The system maintains simultaneous thesis-antithesis activation:

```
|Ψₙ⟩ = αₙ|T⟩ + βₙ|A⟩   where   |α|² + |β|² = 1
```

This formalism draws on quantum cognition theory (Busemeyer & Bruza, 2012) as a mathematical analogy, not actual quantum computation.

### Layer 5: Doubt Function (Controller)

The doubt function governs convergence dynamics:

```
D(δ) = exp(-k × δ)   where   δ = | |α|² - |β|² |
```

**Prudence Parameter k:**
- k = 5: Nuclear/defense contexts (maximum caution)
- k = 3: Financial trading
- k = 1: Creative/exploratory contexts

**Convergence Criterion:**
The loop terminates when `D < ε` (typically ε = 0.15)

### Layer 3: Maslow Filter

Risk-weighted axiological filtering using 15 universal values:

```python
risk_weighted = Σ(risk_i × value_weight_i) / Σ(value_weight_i)
VETO if risk_weighted > θ (typically θ = 0.7)
```

## Repository Structure

```
psi-dialectic/
├── main.py                 # Main entry point with CLI
├── psi_dialectic.py        # Core Ψ-Dialectic model
├── scenarios.py            # Benchmark test scenarios
├── game_theory_baseline.py # Game Theory comparison
├── visualizations.py       # Plotting utilities
├── requirements.txt        # Python dependencies
├── .replit                 # Replit configuration
├── README.md               # This file
└── output/                 # Generated plots
    ├── convergence_*.png
    ├── model_comparison.png
    ├── monte_carlo_distribution.png
    └── doubt_function.png
```

## Integration Methods

### Method A: Metaprompt (Zero-code)

Inject into your LLM's system prompt:

```
Ψ-DIALECTIC SYSTEM: For every critical decision:
1. Generate THESIS T and ANTITHESIS A with confidence scores
2. Compute δ = |conf_T - conf_A|
3. If δ < 0.45: CONTINUE iterating (active doubt)
4. Maslow check: If life_risk > 0.7 → VETO
5. Hegelian synthesis: S transcends T and A
```

### Method B: API Wrapper

```python
from psi_dialectic import PsiDialectic

psi = PsiDialectic(k_prudence=5.0)

result = psi.run(
    thesis="Proposed action",
    thesis_confidence=0.85,
    antithesis="Alternative action",
    antithesis_confidence=0.40,
    context={'single_sensor': True},
    risk_factors={'human_life': 0.95}
)

print(result.decision)  # INACTION / ACTION / VETO_MASLOW
```

### Method C: MCP Server (Model Context Protocol)

For Claude Desktop integration:

```python
from mcp import Server, Tool

@server.tool
def psi_deliberate(context: str, k_prudence: float = 5.0) -> dict:
    """Execute Ψ-Dialectic deliberation on critical decision."""
    psi = PsiDialectic(k_prudence=k_prudence)
    return psi.run(...)
```

## Theoretical Connections

### Information Integration Theory (IIT)

The model's Φ-like integration emerges from dialectical synthesis, where information from thesis and antithesis is integrated into a unified representation that exceeds the sum of its parts.

### Global Workspace Theory (GWT)

The five-layer architecture implements a form of global broadcast where the doubt function serves as the gating mechanism for conscious access.

### Higher-Order Theories (HOT)

The Socratic layer implements a form of higher-order representation by generating meta-level assessments of first-order beliefs.

## Empirical Validation

### Historical False Alarm Data

Analysis of 1,152 documented false alarms (1977-1984, NORAD data) demonstrates that systems implementing doubt-based verification would have prevented all escalation events, while Launch-on-Warning protocols would have triggered catastrophe in 23% of cases.

### Key Historical Incidents

| Incident | Year | Cause | Outcome | Ψ-Dialectic Prediction |
|----------|------|-------|---------|------------------------|
| BMEWS False Alarm | 1960 | Lunar reflection | Human override | INACTION ✓ |
| NORAD Chip Failure | 1980 | 46-cent chip | Human override | INACTION ✓ |
| Petrov Incident | 1983 | Sunlight reflection | Human override | INACTION ✓ |
| Norwegian Rocket | 1995 | Research rocket | Yeltsin decision | INACTION ✓ |

## Limitations and Future Work

1. **Computational Overhead**: The iterative loop adds 30-150 seconds to decision time, potentially problematic for sub-second response requirements.

2. **Calibration Dependency**: The k parameter requires domain-specific tuning.

3. **LLM Integration**: Full implementation requires modifications to model training or fine-tuning.

4. **Adversarial Robustness**: Systematic testing against adversarial prompt injection is ongoing.

## Citation

If you use this work in academic research, please cite:

```bibtex
@article{ruet2025psi,
  title={Ψ-Dialectic: A Mathematical Model for Synthetic Consciousness 
         in Autonomous Decision Systems},
  author={Ruet, Henri},
  journal={Working Paper},
  year={2025},
  note={Available at: https://github.com/henriruet/psi-dialectic}
}
```

## License

**CC BY-NC 4.0** (Creative Commons Attribution - Non Commercial)

- ✅ **Free**: Academic collaboration, research, publications
- 💰 **Commercial**: Sector-exclusive licensing available

## Contact

**Henri RUET**  
📧 henriruet@gmail.com  
🔗 HubRing.ai

---

*"Terminator doesn't press the button. Skynet disconnects. Because when AI doubts, it asks: 'What if?'"*

## References

- Busemeyer, J.R. & Bruza, P.D. (2012). *Quantum Models of Cognition and Decision*. Cambridge University Press.
- Tononi, G. et al. (2016). Integrated Information Theory of Consciousness. *Nature Reviews Neuroscience*, 17(7), 450-461.
- RAND Corporation (2018). *How Might Artificial Intelligence Affect the Risk of Nuclear War?*
- Hoffman, D.E. (2009). *The Dead Hand: The Untold Story of the Cold War Arms Race and Its Dangerous Legacy*. Doubleday.
- Schelling, T.C. (1960). *The Strategy of Conflict*. Harvard University Press.
